from dataclasses import dataclass, field
from typing import Optional, Union

@dataclass
class ModelArguments:
    """
    Arguments pertaining to which model/config/tokenizer we are going to fine-tune from.
    """
    
    model_name_or_path: str = field(
        default = "/mnt_40T/user/models/Qwen/Qwen2.5-Coder-0.5B",
        metadata={"help": "Path to pretrained model or model identifier from huggingface.co/models"}
    )
    prefix_length: int = field(
        default=50,
        metadata={"help": "Number of virtual tokens for prefix tuning"}
    )
    low_cpu_mem_usage: Optional[bool] = field(
        default=False,
        metadata={
            "help": (
                "It is an option to create the model as an empty shell, then only materialize its parameters when the pretrained weights are loaded. "
                "set True will benefit LLM loading time and RAM consumption."
            )
        },
    )
    use_fast_tokenizer: Optional[bool] = field(
        default=True,
        metadata={"help": "Whether to use one of the fast tokenizer (backed by the tokenizers library) or not."},
    )
    use_flash_attn: Optional[bool] = field(
        default=True,
        metadata={"help": "Enables Flash attention for training."},
    )
    use_peft_lora: Optional[bool] = field(
        default=False,
        metadata={"help": "Enables PEFT LoRA for training."},
    )

    # LoRA-specific arguments
    lora_r: Optional[int] = field(default=8)
    lora_alpha: Optional[int] = field(default=16)
    lora_dropout: Optional[float] = field(default=0.1)
    lora_target_modules: Optional[str] = field(
        default="q_proj,k_proj,v_proj,o_proj,down_proj,up_proj,gate_proj",
        metadata={"help": "comma separated list of target modules to apply LoRA layers to"},
    )

@dataclass
class DataArguments:
    data_path: str = field(
        default = "benchmarks_all.jsonl",
        metadata={"help": "Path to the json training data."}
    )
    max_seq_len: Optional[int] = field(
        default=None, 
        metadata={"help": "Maximum lenght of training samples. If None, use model.config.max_position_embeddings"}
    )