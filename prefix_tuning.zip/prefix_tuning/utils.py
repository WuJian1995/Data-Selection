import json
import copy
import torch
from torch.utils.data import Dataset
import transformers
from dataclasses import dataclass
from typing import Dict, List, Any, Optional, Union
from transformers import default_data_collator

IGNORE_TOKEN_ID = -100


def custom_data_collator(features):
    batch = default_data_collator(features)
    batch["labels"] = batch["input_ids"].clone()
    #batch["sample_idx"] = torch.tensor([feature['sample_idx'] for feature in features], dtype=torch.long)
    return batch


class SoftDataset(Dataset):
    """Dataset class for soft prompt tuning with unique soft tokens per sample."""

    def __init__(self, data_path: str, tokenizer: transformers.PreTrainedTokenizerBase, max_seq_len: int, length: int):
        super().__init__()
        self.tokenizer = tokenizer
        self.max_seq_len = max_seq_len

        print("Loading data...")
        self.length = length
        self.raw_data = self.load_data(data_path,length)
        

        # cache mechanism
        self.cached_data_dict = {}
    
    def __len__(self):
        return len(self.raw_data)

    @staticmethod
    def load_data(data_path: str, length: int) -> List[Dict[str, Any]]:
        data = []
        try:
            with open(data_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except json.JSONDecodeError:
            with open(data_path, 'r', encoding='utf-8') as f:
                for line in f:
                    data.append(json.loads(line))
        return data[:length]
    
    def __getitem__(self, idx) -> Dict[str, List[int]]:
        if idx in self.cached_data_dict:
            return self.cached_data_dict[idx]
        
        sample = self.raw_data[idx]
        # text = sample['text'] # FIXME
        text = "<|im_start|>user\n" + sample  + "<|im_end|>"

        encoding = self.tokenizer(text, 
                                truncation=True, 
                                max_length=self.max_seq_len,
                                padding='max_length', 
                                return_tensors='pt')

        input_ids = encoding['input_ids'].squeeze(0) #[seq_len]
        attention_mask = encoding['attention_mask'].squeeze(0) #[seq_len]

        res = {
            'input_ids': input_ids,
            'attention_mask': attention_mask,
            'sample_idx': idx
        }

        self.cached_data_dict[idx] = res

        return res


def create_dataset(
    tokenizer: transformers.PreTrainedTokenizerBase, data_path: str, max_seq_len: int, length: int
) -> Dataset:

    train_dataset = SoftDataset(data_path, tokenizer, max_seq_len,length)

    return train_dataset