import sys
import logging
import os
import torch
import transformers
from peft import PrefixTuningConfig, get_peft_model
from arguments import ModelArguments, DataArguments
from transformers import (
    AutoConfig,
    AutoModelForCausalLM,
    AutoTokenizer,
    Trainer,
    TrainingArguments,
    HfArgumentParser,
    set_seed
)
from utils import create_dataset, custom_data_collator
logger = logging.getLogger(__name__)

def main():
    parser = HfArgumentParser((ModelArguments, DataArguments, TrainingArguments))
    model_args, data_args, training_args = parser.parse_args_into_dataclasses()
    local_rank = int(os.getenv('LOCAL_RANK', '0'))
    if local_rank == 0:
        print(f"model_args = \n {model_args}")
        print(f"data_args = \n {data_args}")
        print(f"training_args = \n {training_args}")

    # Set seed for reproducibility
    set_seed(training_args.seed)

    # create output_dir 
    if not os.path.exists(training_args.output_dir):
        os.makedirs(training_args.output_dir)

    # Setup logging
    logging.basicConfig(
        format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
        datefmt="%m/%d/%Y %H:%M:%S",
        handlers=[logging.StreamHandler(sys.stdout),
                  logging.FileHandler(os.path.join(training_args.output_dir, "training.log"), mode='a'),],
    )

    if training_args.should_log:
        # The default of training_args.log_level is passive, so we set log level at info here to have that default.
        transformers.utils.logging.set_verbosity_info()

    log_level = training_args.get_process_log_level()
    logger.setLevel(log_level)
    transformers.utils.logging.set_verbosity(log_level)
    transformers.utils.logging.enable_default_handler()
    transformers.utils.logging.enable_explicit_format()
    
    # Log on each process the small summary:
    logger.warning(
        f"Process rank: {training_args.local_rank}, device: {training_args.device}, n_gpu: {training_args.n_gpu}, "
        + f"distributed training: {training_args.parallel_mode.value == 'distributed'}, 16-bits training: {training_args.fp16}"
    )
    # logger.info(f"Model parameters {model_args}")
    # logger.info(f"Training parameters {training_args}")


    # load config
    config = AutoConfig.from_pretrained(
        model_args.model_name_or_path,
    )
    if not data_args.max_seq_len:
        data_args.max_seq_len = getattr(config, "max_position_embeddings", None)
    if not data_args.max_seq_len:
        raise ValueError("Please specify the maximum training sample length, for example --max_seq_len 2048")
    logger.info(f"Data parameters {data_args}")

    compute_dtype = torch.float16 if training_args.fp16 else (torch.bfloat16 if training_args.bf16 else torch.float32)
    logger.info(f"compute_dtype = {compute_dtype}")


    # load tokenizer
    tokenizer = AutoTokenizer.from_pretrained(
        model_args.model_name_or_path,
        use_fast=model_args.use_fast_tokenizer,
    )
    if not tokenizer.pad_token_id:
        tokenizer.pad_token_id = tokenizer.eos_token_id
    tokenizer.padding_side = "right"
    
    logger.info(f"Tokenizer Class: {tokenizer.__class__.__name__}")
    logger.info(f"PAD Token/Id: {tokenizer.pad_token}/{tokenizer.pad_token_id}")
    logger.info(f"BOS Token/Id: {tokenizer.bos_token}/{tokenizer.bos_token_id}")
    logger.info(f"EOS Token/Id: {tokenizer.eos_token}/{tokenizer.eos_token_id}")

    # load data and set data collator
    train_dataset = create_dataset(tokenizer, data_args.data_path, data_args.max_seq_len,-1)
    
    model = AutoModelForCausalLM.from_pretrained(model_args.model_name_or_path)
    peft_config = PrefixTuningConfig(
        task_type="CAUSAL_LM",
        num_virtual_tokens=model_args.prefix_length,
        num_layers=model.config.num_hidden_layers,
        encoder_hidden_size=model.config.hidden_size
    )
    model = get_peft_model(model, peft_config)  
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    logger.info("=" * 80)
    logger.info(f"Total parameters: {total_params:,}")
    logger.info(f"Trainable parameters: {trainable_params:,}")
    logger.info(f"Trainable%: {100 * trainable_params / total_params:.2f}%")
    logger.info("=" * 80)

    # get trainer
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        tokenizer=tokenizer,
        data_collator=custom_data_collator
    )

    checkpoint = None
    if training_args.resume_from_checkpoint is not None:
        checkpoint = training_args.resume_from_checkpoint
    train_result = trainer.train(resume_from_checkpoint=checkpoint)

    def save_prefix_model(model, output_dir):
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

        # Extract and save the prefix tuning components
        if hasattr(model, 'peft_layer'):
            for name, peft_module in model.peft_layer.named_modules():
                # Save each prefix tuning layer/component to the output directory
                # This is a placeholder; adapt it based on how the model stores its prefix components
                prefix_path = os.path.join(output_dir, f'{name}_prefix.pt')
                torch.save(peft_module.state_dict(), prefix_path)
                logger.info(f'Saved prefix layer {name} to {prefix_path}')
        
    save_prefix_model(model, training_args.output_dir)

    model.save_pretrained(training_args.output_dir)
    tokenizer.save_pretrained(training_args.output_dir)
    config.save_pretrained(training_args.output_dir)
    logger.info(f"Complete model saved in {training_args.output_dir}")

    metrics = train_result.metrics
    trainer.log_metrics("train", metrics)
    trainer.save_metrics("train", metrics)
    trainer.save_state()  # save training states, including optimizer and scheduler states

if __name__ == "__main__":
    main()
