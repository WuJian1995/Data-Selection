export CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7

pip install --upgrade pip
pip install peft==0.14.0
pip install transformers==4.44.2
pip install transformers-stream-generator==0.0.5
pip install --upgrade accelerate
pip install tensorboardX

torchrun --nproc_per_node 8  prefix_tuning.py \
--prefix_length 30 \
--model_name_or_path "/mnt_40T/user/models/Qwen/Qwen2.5-Coder-0.5B" \
--use_fast_tokenizer True \
--use_flash_attn True \
--data_path benchmarks_all.jsonl \
--max_seq_len 796 \
--output_dir "/ainative/codefuse/user/440218/Experiments/prefix_tuning_models/prefix_model_coder_0.5b_30/" \
--overwrite_output_dir True \
--gradient_checkpointing False \
--num_train_epochs 100 \
--per_device_train_batch_size 4 \
--gradient_accumulation_steps 1 \
--learning_rate 1e-3 \
--lr_scheduler_type "linear" \
--warmup_steps 0 \
--save_strategy "no" \
--fp16 True \
--logging_strategy "steps" \
--logging_steps 1 \
--logging_dir "/ainative/codefuse/user/440218/Experiments/prefix_model_coder_0.5b_30/logs" \
--report_to "tensorboard"