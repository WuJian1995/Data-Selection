export CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7
pip install --upgrade pip
pip install --upgrade transformers peft
pip install peft==0.14.0
pip install transformers-stream-generator==0.0.5
pip install transformer_engine==1.4.0+0fbc76a
pip install --upgrade accelerate
gpus=(0)
model_name_or_path="/mnt_40T/user/models/Qwen/Qwen2.5-Coder-0.5B/"
model_dir="/ainative/codefuse/user/440218/Experiments/prefix_tuning_models/prefix_model_coder_0.5b/"
input_paths=(
    "/ainative/codefuse/user/440218/Experiments/sft_data/code_sft_data_32/Python_sft_split_1_1.jsonl"
    # "/ainative/codefuse/user/440218/Experiments/sft_data/code_sft_data_32/Python_sft_split_1_2.jsonl"
    # "/ainative/codefuse/user/440218/Experiments/sft_data/code_sft_data_32/Python_sft_split_1_3.jsonl"
    # "/ainative/codefuse/user/440218/Experiments/sft_data/code_sft_data_32/Python_sft_split_1_4.jsonl"
    # "/ainative/codefuse/user/440218/Experiments/sft_data/code_sft_data_32/Python_sft_split_2_1.jsonl"
    # "/ainative/codefuse/user/440218/Experiments/sft_data/code_sft_data_32/Python_sft_split_2_2.jsonl"
    # "/ainative/codefuse/user/440218/Experiments/sft_data/code_sft_data_32/Python_sft_split_2_3.jsonl"
    # "/ainative/codefuse/user/440218/Experiments/sft_data/code_sft_data_32/Python_sft_split_2_4.jsonl"
    )
output_path=/ainative/codefuse/user/440218/Experiments/sft_data/prefix_selected_code_data_0.5b/
num_virtual_tokens=50
for gpu in "${gpus[@]}"; do
    input_path=${input_paths[$gpu]}
    echo 'GPU:' $gpu,'input_path:' ${input_path}, 'output_path:' ${output_path}
    CUDA_VISIBLE_DEVICES=$gpu python inference_sft_data.py --model_name_or_path ${model_name_or_path} --model_dir ${model_dir} --data_path ${input_path} --output_path ${output_path} --prefix_length ${num_virtual_tokens} --threshold 1.0 &
    sleep 5
done