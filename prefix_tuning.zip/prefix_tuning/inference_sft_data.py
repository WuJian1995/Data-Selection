import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import PrefixTuningConfig, PeftModel, get_peft_model
import torch.nn.functional as F
import json
from tqdm import tqdm
import argparse
import os
import numpy as np

device = "cuda" if torch.cuda.is_available() else "cpu"

def load_data(file_path, max_samples=None):
    """加载并预处理数据"""
    texts = []
    original_data = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for i, line in enumerate(f):
            if max_samples and i >= max_samples:
                break
            try:
                item = json.loads(line)
                prompt = ''
                if 'prompt' in item and 'canonical_solution' in item:
                    prompt = item['prompt'] + '\n' + item['canonical_solution']
                elif 'chat_rounds' in item:
                    for cr in item['chat_rounds']:
                        prompt += cr['content'] + '\n'
                else:
                    continue  # 跳过不支持的格式
                
                original_data.append(item)
                texts.append(prompt)
            except json.JSONDecodeError:
                print(f"Error parsing line {i+1}")
    return texts, original_data

def compute_probability(text, model, tokenizer, max_length=768):
    """计算文本的平均token概率"""
    inputs = tokenizer(
        text, 
        return_tensors="pt", 
        truncation=True, 
        max_length=max_length, 
        padding="max_length"
    ).to(device)
    
    with torch.no_grad():
        outputs = model(**inputs)
        logits = outputs.logits
        
    # 计算每个token的概率
    shift_logits = logits[:, :-1, :].contiguous()
    shift_labels = inputs.input_ids[:, 1:].contiguous()
    
    # 使用交叉熵计算每个token的概率
    loss_fct = torch.nn.CrossEntropyLoss(reduction="none")
    losses = loss_fct(
        shift_logits.view(-1, shift_logits.size(-1)), 
        shift_labels.view(-1)
    )
    per_token_probs = torch.exp(-losses).view(shift_labels.shape)
    
    # 创建mask忽略填充token
    mask = (shift_labels != tokenizer.pad_token_id).float()
    valid_probs = per_token_probs * mask
    
    # 计算平均概率
    sum_probs = valid_probs.sum()
    num_tokens = mask.sum()
    avg_prob = (sum_probs / num_tokens).item() if num_tokens > 0 else 0.0
    
    return avg_prob

def main(model_name_or_path, model_dir, data_path, output_path, threshold, prefix_length, max_samples=None):
    """主处理函数"""
    # 加载tokenizer
    tokenizer = AutoTokenizer.from_pretrained(model_dir)
    
    # 确保有pad token
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    # 加载微调后的模型
    print("Loading tuned model...")
    def load_prefix_tuned_model(model_dir, model_name_or_path, prefix_length):
        # Load the base model
        base_model = AutoModelForCausalLM.from_pretrained(model_name_or_path)
        
        # Instantiate the prefix tuning configuration
        peft_config = PrefixTuningConfig(
            task_type="CAUSAL_LM",  # Adjust this to match your task
            num_virtual_tokens=prefix_length,  # This should match what was used during training
            num_layers=base_model.config.num_hidden_layers,
            encoder_hidden_size=base_model.config.hidden_size
        )

        # Apply the prefix configuration when creating the Peft model
        peft_model = get_peft_model(base_model, peft_config)
        
        # Load the prefix tuning components
        for prefix_path in os.listdir(model_dir):
            if prefix_path.endswith("_prefix.pt"):
                prefix_state_dict = torch.load(os.path.join(model_dir, prefix_path))
                component_name = prefix_path.replace("_prefix.pt", "")
                getattr(peft_model.peft_layer, component_name).load_state_dict(prefix_state_dict)
        
        return peft_model
    tuned_model = load_prefix_tuned_model(model_dir, model_name_or_path,prefix_length)
    tuned_model.to(device)
    tuned_model.eval()
    
    # 加载微调前的模型
    print("Loading fine-tuned model...")
    base_model = AutoModelForCausalLM.from_pretrained(model_name_or_path)
    peft_config = PrefixTuningConfig(
            task_type="SEQ_CLS",
            num_virtual_tokens=prefix_length,
            num_layers=base_model.config.num_hidden_layers,
            encoder_hidden_size=base_model.config.hidden_size
    )
    base_model = get_peft_model(base_model, peft_config)
    base_model.to(device)
    base_model.eval()
    
    # 加载数据
    print("Loading data...")
    texts, original_data = load_data(data_path, max_samples)
    
    # 创建输出目录
    os.makedirs(output_path, exist_ok=True)
    file_name = os.path.basename(data_path)
    output_file = os.path.join(output_path, f"selected_threshold_{threshold:.2f}_{file_name}")
    
    # 处理数据
    selected_data = []
    ratio_list = []
    
    for i, text in enumerate(tqdm(texts, desc="Processing texts")):
        try:
            # 计算两种模型的概率
            base_prob = compute_probability(text, base_model, tokenizer)
            tuned_prob = compute_probability(text, tuned_model, tokenizer)
            
            # 计算概率比
            if base_prob > 0:  # 避免除以0
                prob_ratio = tuned_prob / base_prob
                ratio_list.append(prob_ratio)
                
                # 根据阈值选择
                if prob_ratio > threshold:
                    
                    selected_data.append(original_data[i])
                else:
                    print(text, prob_ratio)
        except Exception as e:
            print(f"Error processing text {i+1}: {str(e)}")
    
    # 保存结果
    print(f"Selected {len(selected_data)}/{len(texts)} samples (threshold={threshold})")
    with open(output_file, 'w', encoding='utf-8') as f:
        for item in selected_data:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')
    
    # 保存统计信息
    stats = {
        "total_samples": len(texts),
        "selected_samples": len(selected_data),
        "threshold": threshold,
        "min_ratio": min(ratio_list) if ratio_list else 0,
        "max_ratio": max(ratio_list) if ratio_list else 0,
        "mean_ratio": np.mean(ratio_list) if ratio_list else 0,
        "median_ratio": np.median(ratio_list) if ratio_list else 0
    }
    stats_file = os.path.join(output_path, f"stats_threshold_{threshold:.2f}.json")
    with open(stats_file, 'w', encoding='utf-8') as f:
        json.dump(stats, f, indent=2)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Filter data using model probability ratios')
    parser.add_argument('--model_name_or_path', type=str, required=True, help='Path to pretrained model')
    parser.add_argument('--model_dir', type=str, required=True, help='Path to prefix tuned model')
    parser.add_argument('--data_path', type=str, required=True, help='Path to input data')
    parser.add_argument('--output_path', type=str, required=True, help='Path to save results')
    parser.add_argument('--prefix_length', type=int, default=30, help='Path to save results')
    parser.add_argument('--threshold', type=float, default=1.0, help='Selection threshold')
    parser.add_argument('--max_samples', type=int, default=None, help='Maximum samples to process')
    
    args = parser.parse_args()
    
    main(
        model_name_or_path = args.model_name_or_path,
        model_dir=args.model_dir,
        data_path=args.data_path,
        output_path=args.output_path,
        threshold=args.threshold,
        prefix_length=args.prefix_length,
        max_samples=args.max_samples
    )